﻿using System;

namespace _09.SpiceMustFlow
{
    class Program
    {
        static void Main(string[] args)
        {
            int startingYield = int.Parse(Console.ReadLine());
            int days = 0;

            int totalYield = 0;

            if (startingYield >= 100)
            {
                while (startingYield >= 100)
                {
                    totalYield += startingYield;
                    totalYield -= 26;
                    startingYield -= 10;
                    days++;
                }
                totalYield -= 26;
            }
            Console.WriteLine(days);
            Console.WriteLine(totalYield);
        }
    }
}
