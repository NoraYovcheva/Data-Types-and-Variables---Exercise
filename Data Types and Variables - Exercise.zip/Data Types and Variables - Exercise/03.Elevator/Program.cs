﻿using System;

namespace _03.Elevator
{
    class Program
    {
        static void Main(string[] args)
        {
            int peopleCount = int.Parse(Console.ReadLine());
            int capacity = int.Parse(Console.ReadLine());

            decimal courses = Math.Ceiling((decimal)peopleCount / capacity);

            Console.WriteLine($"{courses}");
            
        }
    }
}
