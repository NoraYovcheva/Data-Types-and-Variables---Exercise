﻿using System;

namespace _11.Snowballs
{
    class Program
    {
        static void Main(string[] args)
        {
            int snowballSnow = int.Parse(Console.ReadLine());
            int snowballTime = int.Parse(Console.ReadLine());
            int snowballQuality = int.Parse(Console.ReadLine());

            double snowballValue = (snowballSnow / snowballTime) / snowballQuality;

            Console.WriteLine($"{snowballSnow} : {snowballTime} = {snowballValue} ({snowballQuality})");
        }
    }
}
